package org.phantom.intellij.ide.systemProperties.actions;

import com.intellij.openapi.actionSystem.AnActionEvent;
import com.intellij.openapi.actionSystem.DataConstants;
import com.intellij.openapi.actionSystem.ToggleAction;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.wm.ToolWindow;
import com.intellij.openapi.wm.ToolWindowAnchor;
import com.intellij.openapi.wm.ToolWindowManager;
import org.phantom.intellij.ide.systemProperties.SystemPropertiesView;

import javax.swing.*;
import java.util.*;


/**
 * Toggle Properties SystemPropertiesView
 * @author <a href="mailto:aefimov@spklabs.com>Alexey Efimov</a>
 */
public class SystemPropertiesToggle extends ToggleAction {
  public static final String ID = "ViewSystemPropertiesWindow";
  private static final Icon ICON = new ImageIcon(SystemPropertiesToggle.class.getResource("toggle.gif"));
  private Map consoles = new HashMap();
  private List managers = new ArrayList();

  public boolean isSelected(AnActionEvent event) {
    Project project = (Project)event.getDataContext().getData(DataConstants.PROJECT);
    return project != null && consoles.get(project) != null;
  }

  public void setSelected(AnActionEvent event, boolean isSelected) {
    Project project = (Project)event.getDataContext().getData(DataConstants.PROJECT);
    if (project != null) {
      final ToolWindowManager manager = ToolWindowManager.getInstance(project);
      ToolWindow console = (ToolWindow)consoles.get(project);
      if (isSelected && console == null) {
        // Show window
        manager.registerToolWindow(SystemPropertiesView.ID, new SystemPropertiesView(System.getProperties()), ToolWindowAnchor.BOTTOM);
        console = manager.getToolWindow(SystemPropertiesView.ID);
        if (console != null) {
          // Add manager to array to do unregister on finalize
          managers.add(manager);
          consoles.put(project, console);
          console.setIcon(ICON);
          console.show(null);
          console.activate(null);
        }
      } else if (!isSelected && console != null) {
        // Hide window
        console.hide(null);
        manager.unregisterToolWindow(SystemPropertiesView.ID);
        managers.remove(manager);
        consoles.remove(project);
      }
    }
  }

  public SystemPropertiesToggle() {
    super(SystemPropertiesView.ID, "Show/Hide " + SystemPropertiesView.ID, ICON);
  }

  public void clear() {
    // Unregister all ToolWindows
    Iterator iterator = managers.iterator();
    while (iterator.hasNext()) {
      ToolWindowManager manager = (ToolWindowManager)iterator.next();
      manager.unregisterToolWindow(SystemPropertiesView.ID);
    }
    managers.clear();
    consoles.clear();
  }

}