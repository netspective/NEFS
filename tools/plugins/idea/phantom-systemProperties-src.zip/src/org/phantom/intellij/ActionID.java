package org.phantom.intellij;

/**
 * Common Action Ids
 * @author <a href="mailto:aefimov@spklabs.com>Alexey Efimov</a>
 */
public class ActionID {
  public static final String MAIN_TOOLBAR = "MainToolBar";
  public static final String MAIN_MENU = "MainMenu";
  public static final String WINDOW_MENU = "WindowMenu";
  public static final String WINDOW_MENU_INSPECTION = "ViewInspectionWindow";
}
