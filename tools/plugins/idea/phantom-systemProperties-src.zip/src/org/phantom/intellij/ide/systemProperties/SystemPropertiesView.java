package org.phantom.intellij.ide.systemProperties;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.*;

/**
 * Tool Window
 * @author <a href="mailto:aefimov@spklabs.com>Alexey Efimov</a>
 */
public class SystemPropertiesView extends JPanel {
  public final static String ID = "System Properties";

  private final static class PropertiesTableMode extends AbstractTableModel {
    private String[] names;
    private Properties properties;

    public PropertiesTableMode(Properties properties) {
      this.properties = properties;
      if (properties != null) {
        names = new String[properties.size()];
        int i = 0;
        Iterator iterator = properties.keySet().iterator();
        while (iterator.hasNext()) {
          names[i++] = (String)iterator.next();
        }
      } else {
        this.properties = new Properties();
        names = new String[]{};
      }
      sortAsc();
    }

    public void sortAsc() {
      Arrays.sort(names);
    }

    public int getRowCount() {
      return names.length;
    }

    public int getColumnCount() {
      return 2;
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
      if (columnIndex == 0) {
        return names[rowIndex];
      } else {
        return properties.getProperty(names[rowIndex]);
      }
    }

    public String getColumnName(int column) {
      switch (column) {
        case 0:
          return "Name";
        case 1:
          return "Value";
        default:
          return super.getColumnName(column);
      }
    }
  }

  public SystemPropertiesView(Properties properties) {
    super(new BorderLayout());
    JTable jTable = new JTable(new PropertiesTableMode(properties));
    jTable.setRowSelectionAllowed(true);
    jTable.setBackground(Color.white);
    JScrollPane jScrollPane = new JScrollPane(jTable);
    this.add(jScrollPane, BorderLayout.CENTER);
  }
}
